package com.mopix.olineshopapp.models.site

data class Content(
    var id: Long?,
    var description: String?,
    var title: String?
)
