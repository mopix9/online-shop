package com.mopix.olineshopapp.models.products

data class ProductColor(
    var hexValue: String?,
    var id: Long?,
    var title: String?
)
