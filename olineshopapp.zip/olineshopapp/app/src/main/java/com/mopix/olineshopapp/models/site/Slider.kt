package com.mopix.olineshopapp.models.site

data class Slider(
    var id: Long?,
    var image: String?,
    var link: String?,
    var subTitle: String?,
    var title: String?
)
