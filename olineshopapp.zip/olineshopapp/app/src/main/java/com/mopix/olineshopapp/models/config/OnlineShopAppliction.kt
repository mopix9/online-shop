package com.mopix.olineshopapp.models.config

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class OnlineShopAppliction :Application(){
}