package com.mopix.olineshopapp.models.products

data class ProductSize(
    var id: Long?,
    var title: String?
)
