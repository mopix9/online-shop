package com.mopix.olineshopapp.view.utiles

class ThisApp {
    companion object {
        var invoiceId: Long = 0
        var token: String = ""
        var userId: Long = 0
        var productCategoryId: Long = 0
    }
}