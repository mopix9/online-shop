package com.mopix.olineshopapp.view.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)
val Dark = Color(0xFF000000)
val Red = Color(0xFFD12626)
val lightBlue = Color(0xFF52A2E2)
val IranianGreen = Color(0xFF0C887C)

