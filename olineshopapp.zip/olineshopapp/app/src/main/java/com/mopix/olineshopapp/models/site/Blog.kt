package com.mopix.olineshopapp.models.site

data class Blog (
var addDate: String?,
var description: String?,
var id: Long?,
var subTitle: String?,
var title: String?,
var visitCount: Int
        )